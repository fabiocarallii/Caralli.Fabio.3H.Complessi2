﻿using System;

namespace Caralli.Fabio._3H.Complessi2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("programma di fabio caralli sui complessi");

            Complesso z1 = new Complesso(3, 5);
            Complesso z2 = new Complesso(2, 1);
            Complesso Ztot = new Complesso();
            Console.WriteLine("scegli una delle quattro operazioni\r\n");
            Console.WriteLine("somma 1 \r\n sottrazione 2 \r\n moltiplicazione 3 \r\n divisione 4 \r\n ");
            string N = Console.ReadLine();
            if (N == "1")
            {
                Ztot.somma(z1, z2);
                Console.WriteLine($"la somma dei numeri è {Ztot.reali} {Ztot.immaginaria}i");
            }
            if (N == "2")
            {
                Ztot.sottrazione(z1, z2);
                Console.WriteLine($"la sottrazione dei numeri è {Ztot.reali} {Ztot.immaginaria}i");

            }
            if (N == "3")
            {
                Ztot.moltiplicazione(z1, z2);
                Console.WriteLine($"la moltiplicazione dei numeri è {Ztot.reali} {Ztot.immaginaria}i");

            }
            if (N == "4")
            {
                Ztot.divisione(z1, z2);
                Console.WriteLine($"la divisione dei numeri è {Ztot.reali} {Ztot.immaginaria}i");

            }
        }

        class Complesso
        {
            public double reali;
            public double immaginaria;

            public Complesso()
            {

            }

            public Complesso(int a, int b)
            {
                reali = a;
                immaginaria = b;
            }
            public void somma(Complesso z1, Complesso z2)
            {
                reali = z1.reali + z2.reali;
                immaginaria = z1.immaginaria + z2.immaginaria;

            }
            public void sottrazione(Complesso z1, Complesso z2)
            {
                reali = z1.reali - z2.reali;
                immaginaria = z1.immaginaria - z2.immaginaria;
            }
            public void moltiplicazione(Complesso z1, Complesso z2)
            {
                reali = (z1.reali * z2.reali) - (z1.immaginaria * z2.immaginaria);
                immaginaria = (z1.immaginaria * z2.immaginaria) + (z2.reali * z2.immaginaria);
            }
            public void divisione(Complesso z1, Complesso z2)
            {
                reali = (z1.reali * z1.reali + z1.immaginaria * z2.immaginaria) / (Math.Pow(z2.reali, 2) + Math.Pow(z2.reali, 2));
                immaginaria = (z1.immaginaria * z2.reali - z1.immaginaria * z2.immaginaria) / (Math.Pow(z2.reali, 2) + Math.Pow(z2.reali, 2));
            }
        }
    }
}
